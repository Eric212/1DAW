public class Ejercicio1{
	public static void main(String[] args){
		int numero=45;
		while(numero>=45&&numero<=100){
			System.out.println(numero);
			numero++;
		}
	}
}