public class Ejercicio2{
	public static void main(String[] args){
		int numero=0;
		int contador;
		for(contador=1;contador<=1000;contador++){
			numero=numero+contador;
			System.out.println(numero);
		}
	}
}