import java.util.Scanner;
public class Ejercicio9{
	public static void main(String[] args){
		Scanner lector=new Scanner(System.in);
		System.out.println("Introudce el numero que quieras comprobar que es primo");
		int tam=lector.nextInt();
		lector.nextLine();
		int[] numeros = new int[tam];
		tam=tam-1;
		int i;
		boolean comprobante;
		int x=1;
		int contador=0;
		for(i=1;contador<=tam;i++){
			if(i/x==1){
				numeros[contador]=i;
				contador++;
			}else{
				x++;
			}
		}
		comprobante=false;
		tam=tam+1;
		for (int z=0; z<numeros.length; z++){
  		if(numeros[z]==tam){
			  System.out.println("Es primo");
			  comprobante=true;
  			}
		}
		if(comprobante!=true){
			System.out.println("No es primo");
		}
	}
}