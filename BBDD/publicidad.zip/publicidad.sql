-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-03-2021 a las 15:25:10
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `publicidad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anuncios`
--

CREATE TABLE `anuncios` (
  `id` int(11) NOT NULL,
  `longitud` float DEFAULT NULL,
  `latitud` float DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `alto` int(11) DEFAULT NULL,
  `ancho` int(11) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `anuncios`
--

INSERT INTO `anuncios` (`id`, `longitud`, `latitud`, `direccion`, `precio`, `alto`, `ancho`, `descripcion`) VALUES
(1, 38.784, 0.183269, 'Avda. Mediterráneo 33', 1000, 300, 600, 'Primera línea mar, muchos transeuntes'),
(2, 38.7789, 0.10531, 'Ctra. Gata 13', 600, 400, 700, 'Mucho tráfico en vacaciones, velocidad moderada'),
(3, 38.8029, 0.196358, 'Cabo de San Antonio', 890, 350, 650, 'Mucho guiri haciendo fotos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `cif` varchar(10) NOT NULL,
  `razon_social` varchar(100) DEFAULT NULL,
  `nombre_comercial` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`cif`, `razon_social`, `nombre_comercial`) VALUES
('11111111-A', 'Cliente 1, S.A.', 'Cliente 1'),
('22222222-B', 'Cliente 2, S.L.', 'Cliente 2'),
('33333333-C', 'Cliente 3, S.A.', 'Cliente 3'),
('44444444-D', 'Cliente 4, S.L.', 'Cliente 4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contratos`
--

CREATE TABLE `contratos` (
  `fecha_inicio` date NOT NULL,
  `clientes_cif` varchar(10) NOT NULL,
  `anuncios_id` int(11) NOT NULL,
  `meses` int(11) NOT NULL,
  `precio_mes` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `contratos`
--

INSERT INTO `contratos` (`fecha_inicio`, `clientes_cif`, `anuncios_id`, `meses`, `precio_mes`) VALUES
('2021-03-22', '11111111-A', 1, 9, 850),
('2021-03-22', '44444444-D', 2, 12, 400);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `anuncios`
--
ALTER TABLE `anuncios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cif`);

--
-- Indices de la tabla `contratos`
--
ALTER TABLE `contratos`
  ADD PRIMARY KEY (`fecha_inicio`,`clientes_cif`,`anuncios_id`),
  ADD KEY `fk_contratos_clientes_idx` (`clientes_cif`),
  ADD KEY `fk_contratos_anuncios1_idx` (`anuncios_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `anuncios`
--
ALTER TABLE `anuncios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `contratos`
--
ALTER TABLE `contratos`
  ADD CONSTRAINT `fk_contratos_anuncios1` FOREIGN KEY (`anuncios_id`) REFERENCES `anuncios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_contratos_clientes` FOREIGN KEY (`clientes_cif`) REFERENCES `clientes` (`cif`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
