const fondo=document.querySelector('.fondo');
const finPartida=document.querySelector('.finPartida');
const puntuacion=document.querySelector('#puntuacion');
for(let i=0;)
